package com.cg.qgs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/*import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;*/
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.qgs.exceptions.InsuranceException;
import com.cg.qgs.model.AccountCreation;
import com.cg.qgs.model.Policy;
import com.cg.qgs.utility.JdbcUtility;

public class Dao implements IDao {
	String userName;
	PreparedStatement statement = null;
	Connection connection = null;
	ResultSet resultSet = null;
	int result = 0;

	/*
	 * @Override public List<BusinessSegment> getBusinessSegment() throws
	 * InsuranceException { List <BusinessSegment> list = new ArrayList<>();
	 * connection = JdbcUtility.getConnection(); try {
	 * 
	 * statement = connection.prepareStatement(QueryMapper.businessSegment);
	 * resultSet=statement.executeQuery(); while(resultSet.next()) { String
	 * segmentId = resultSet.getString(1); int segmentSequence =
	 * resultSet.getInt(2); String segmentName = resultSet.getString(3);
	 * BusinessSegment segment = new BusinessSegment();
	 * segment.setSegmentName(segmentName); list.add(segment); }
	 * 
	 * } catch (SQLException e) {
	 * 
	 * throw new InsuranceException("Not Inserted"); }
	 * 
	 * return list; }
	 */
	@Override
	public int newAccount(AccountCreation accountCreation, String userName) throws InsuranceException {
		connection = JdbcUtility.getConnection();
		
		long accountNum = 0;
		try {

			statement = connection.prepareStatement(QueryMapper.insertQuery);

			statement.setString(1, accountCreation.getInsuredName());
			statement.setString(2, accountCreation.getInsuredStreet());
			statement.setString(3, accountCreation.getInsuredCity());
			statement.setString(4, accountCreation.getInsuredState());
			statement.setLong(5, accountCreation.getInsuredZip());
			statement.setString(6, userName);
			result = statement.executeUpdate();
			statement = connection.prepareStatement(QueryMapper.viewAccountNum);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				accountNum = resultSet.getLong(1);
			}
			System.out.println("Your Account Number is : " + accountNum);

		} catch (SQLException e) {

			// throw new InsuranceException("Not Inserted");
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public List<Policy> viewPolicy() throws InsuranceException {
		List<Policy> list = new ArrayList<>();
		userName = "agent";
		connection = JdbcUtility.getConnection();
		
try {
	
	statement = connection.prepareStatement(QueryMapper.viewPolicy);
	statement.setString(1, userName);
	resultSet = statement.executeQuery();
	while(resultSet.next()) {
		 String businessSegment = resultSet.getString(1);
		 long policyNumber = resultSet.getLong(2);
		 double policyPremium = resultSet.getDouble(3);
		 long accountNumber = resultSet.getLong(4);
		 Policy policy = new Policy();
		 policy.setBusinessSegment(businessSegment);
		 policy.setPolicyNumber(policyNumber);
		 policy.setPolicyPremium(policyPremium);
		 policy.setAccountNumber(accountNumber);
		 list.add(policy);
		 
	}
	
	
	
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
		return list;
	}
}
