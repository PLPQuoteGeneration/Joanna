package com.cg.qgs.dao;

public interface QueryMapper {

	public static final String insertQuery = "insert into accounts values(account_number_seq.nextval,?,?,?,?,?,?)";
	public static final String viewAccountNum="select account_number_seq.currval from accounts";
	public static final String viewPolicy = "select * from policy where account_number=(select account_number from accounts where username=?)";
}



               