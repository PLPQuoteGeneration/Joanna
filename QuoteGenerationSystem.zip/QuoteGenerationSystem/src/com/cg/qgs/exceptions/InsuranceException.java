package com.cg.qgs.exceptions;

public class InsuranceException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2262597388651957621L;

	public InsuranceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
