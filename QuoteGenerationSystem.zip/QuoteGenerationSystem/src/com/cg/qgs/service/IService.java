package com.cg.qgs.service;

import java.util.List;

import com.cg.qgs.exceptions.InsuranceException;
import com.cg.qgs.model.AccountCreation;
import com.cg.qgs.model.Policy;


public interface IService {


	int newAccount(AccountCreation accountCreation, String userName) throws InsuranceException;

	

	List<Policy> viewPolicy() throws InsuranceException;


	/*List<BusinessSegment> getBusinessSegment() throws InsuranceException;*/

}
