package com.cg.qgs.service;

import java.util.List;

import com.cg.qgs.dao.Dao;
import com.cg.qgs.dao.IDao;
import com.cg.qgs.exceptions.InsuranceException;
import com.cg.qgs.model.AccountCreation;
import com.cg.qgs.model.Policy;

public class Service implements IService {

	IDao dao = new Dao();

	@Override
	public int newAccount(AccountCreation accountCreation, String userName) throws InsuranceException {

		return dao.newAccount(accountCreation, userName);
	}

	
	

	
	@Override
	public List<Policy> viewPolicy() throws InsuranceException {
		// TODO Auto-generated method stub
		return dao.viewPolicy();
	}

}
