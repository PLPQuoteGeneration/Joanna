package com.cg.qgs.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.qgs.exceptions.InsuranceException;
import com.cg.qgs.model.AccountCreation;
import com.cg.qgs.model.Policy;
import com.cg.qgs.service.IService;
import com.cg.qgs.service.Service;

public class UIMain {
	static String userName = "user";

	public static void main(String[] args) {
		boolean flag = false;
		int choice;
		Scanner scanner = new Scanner(System.in);
		System.out.println("***** User Role *****");
		System.out.println("1. Account Creation");
		System.out.println("2. View the list of Policies available");
		do {
			try {
				do {
					choice = scanner.nextInt();
					scanner.nextLine();

					if (choice == 1 || choice == 2) {
						flag = true;
						switch (choice) {
						case 1:
							account();
							break;

						case 2:
							viewPolicy();
							break;

						}
					} else {
						System.out.println("Enter a valid input i.e either 1 or 2");
					}

				} while (!flag);

			} catch (InputMismatchException e) {
				scanner = new Scanner(System.in);
				System.out.println("Enter an integer only");

			}
		} while (!flag);
		scanner.close();

	}

	public static void account() {
		boolean zipFlag = false;

		boolean pattern = false;
		long insuredZip = 0l;
		String insuredName, insuredStreet, insuredCity, insuredState;
		Scanner scanner = new Scanner(System.in);

		do {
			scanner = new Scanner(System.in);
			System.out.println(" Enter your Name ");
			insuredName = scanner.nextLine();
			String regexName = "[A-Za-z\\s]{1,30}$";
			pattern = Pattern.matches(regexName, insuredName);
			if (!pattern) {
				System.out.println("Enter max 30 characters");
			}
		} while (!pattern);
		System.out.println(" Address ");
		do {
			scanner = new Scanner(System.in);
			System.out.println(" Enter the Street");
			insuredStreet = scanner.nextLine();
			String regexStreet = "[A-Za-z0-9\\s]{1,40}$";
			pattern = Pattern.matches(regexStreet, insuredStreet);
			if (!pattern) {
				System.out.println("Enter max 40 characters");
			}
		} while (!pattern);
		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter the City");
			insuredCity = scanner.nextLine();
			String regexCity = "[A-Za-z\\s]{1,15}$";
			pattern = Pattern.matches(regexCity, insuredCity);
			if (!pattern) {
				System.out.println("Enter max 15 characters");
			}
		} while (!pattern);
		do {
			scanner = new Scanner(System.in);
			System.out.println(" Enter the State");
			insuredState = scanner.nextLine();
			String regexState = "[A-Za-z\\s]{1,15}$";
			pattern = Pattern.matches(regexState, insuredState);
			if (!pattern) {
				System.out.println("Enter max 15 characters");
			}
		} while (!pattern);

		do {
			try {
				scanner = new Scanner(System.in);
				System.out.println(" Enter the Zip");
				insuredZip = scanner.nextLong();
				String zipRegEx = "[0-9]{5}";
				zipFlag = Pattern.matches(zipRegEx, String.valueOf(insuredZip));
				if (!zipFlag) {
					System.err.println("Invalid Zip");
				}
			} catch (InputMismatchException e) {
				zipFlag = false;
				System.err.println("Enter integer only");

			}
		} while (!zipFlag);

		AccountCreation accountCreation = new AccountCreation();
		accountCreation.setInsuredName(insuredName);
		accountCreation.setInsuredStreet(insuredStreet);
		accountCreation.setInsuredCity(insuredCity);
		accountCreation.setInsuredState(insuredState);
		accountCreation.setInsuredZip(insuredZip);
		IService service = new Service();

		int creation = 0;
		try {
			creation = service.newAccount(accountCreation, userName);
			System.out.println(creation + " row inserted");
		} catch (InsuranceException e) {
			e.printStackTrace();
		}
		scanner.close();
	}

	public static void viewPolicy() {

		IService service = new Service();
		System.out.println("List of Policies Available");
		List<Policy> list = null;
		try {
			list = service.viewPolicy();
			if (!list.isEmpty()) {
				System.out.println("BUSINESS SEGMENT" + "   " + "POLICY NUMBER" + "   " + "POLICY PREMIUM" + "   "
						+ "ACCOUNT NUMBER");
			}
			for (Policy policy : list) {
				System.out.println(policy.getBusinessSegment() + "---" + policy.getPolicyNumber() + " --- "
						+ policy.getPolicyPremium() + " --- " + policy.getAccountNumber());
			}
		} catch (InsuranceException e) {
			e.printStackTrace();
		}
	}
}
